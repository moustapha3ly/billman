<?php

return [

    'main_navigation'               => 'NAVIGASI UTAMA',
    'blog'                          => 'Blog',
    'pages'                         => 'Halaman',
    'account_settings'              => 'PENGATURAN AKUN',
    'profile'                       => 'Profil',
    'change_password'               => 'Ubah Kata Sandi',
    'multilevel'                    => 'Multi Level',
    'level_one'                     => 'Level 1',
    'level_two'                     => 'Level 2',
    'level_three'                   => 'Level 3',
    'labels'                        => 'LABEL',
    'important'                     => 'Penting',
    'warning'                       => 'Peringatan',
    'information'                   => 'Informasi',
];
